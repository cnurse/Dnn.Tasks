﻿

CREATE TABLE dbo.dnn_Tasks
(
    ID int IDENTITY(1,1) NOT NULL,
	ModuleID int NOT NULL,
    Name nvarchar(2000) NOT NULL,
    [Description] nvarchar(max) NOT NULL,
    IsComplete [bit] NOT NULL,
    CONSTRAINT [PK_dnn_Tasks]
        PRIMARY KEY CLUSTERED ( [ID] ASC )
)


GO